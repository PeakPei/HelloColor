//
//  Info.h
//  HelloColor
//
//  Created by Jeff on 9/13/14.
//  Copyright (c) 2014 Jeff. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>


#import <UIKit/UIKit.h>

@interface InfoScene : SKScene

@end
