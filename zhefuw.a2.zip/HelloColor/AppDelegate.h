//
//  AppDelegate.h
//  HelloColor
//
//  Created by Jeff on 9/19/14.
//  Copyright (c) 2014 Jeff. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
